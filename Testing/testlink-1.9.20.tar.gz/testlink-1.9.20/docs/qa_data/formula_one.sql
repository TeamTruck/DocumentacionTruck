--- Password for all users: 'star trek'
INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Mark.Webber','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Mark.Webber@formulaone.com','Mark','Webber','en_GB',1,'DEVKEY-Webber');

INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Lewis.Hamilton','9651cbc7c0b5fb1a81f2858a07813c82',9,
            'Lewis.Hamilton@formulaone.com','Lewis','Hamilton','it_IT',1,'DEVKEY-Hamilton');

INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Fernando.Alonso','9651cbc7c0b5fb1a81f2858a07813c82',6,
            'Fernando.Alonso@formulaone.com','Fernando','Alonso','en_GB',1,'DEVKEY-Alonso');


INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Jenson.Button','9651cbc7c0b5fb1a81f2858a07813c82',6,
            'Jenson.Button@formulaone.com','Jenson','Button','en_GB',1,'DEVKEY-Button');
 
INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Sebastian.Vettel','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Sebastian.Vettel@formulaone.com','Sebastian','Vettel','en_GB',1,'DEVKEY-Vettel');


INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Felipe.Massa','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Felipe.Massa@formulaone.com','Felipe','Massa','en_GB',1,'DEVKEY-Massa');


INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Nico.Rosberg','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Nico.Rosberg@formulaone.com','Nico','Rosberg','en_GB',1,'DEVKEY-Rosberg');


INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Robert.Kubica','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Robert.Kubica@formulaone.com','Robert','Kubica','en_GB',1,'DEVKEY-Kubica');


INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Michael.Schumacher','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Michael.Schumacher@formulaone.com','Michael','Schumacher','en_GB',1,'DEVKEY-Schumacher');


INSERT INTO users(
            "login", "password", role_id, email, "first", "last", locale,active, script_key)
    VALUES ('Adrian.Sutil','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Adrian.Sutil@formulaone.com','Adrian','Sutil','en_GB',1,'DEVKEY-Sutil');

 